﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class Circle
    {
        public int x { get; set; }
        public int y { get; set; }

        public Circle()
        {
            x = 0;
            y = 0;
        }
    }
}
