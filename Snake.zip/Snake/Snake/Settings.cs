﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    public enum Direction { Up,Down,Left,Right};
    class Settings
    {
        public static int width { get; set; }
        public static int height { get; set; }
        public static int speed { get; set; }  //speed of the snake
        public static int score { get; set; }  //total score of the current game
        public static int points { get; set; }  //how many points will be added each time the snake will eat a food
        public static bool gameOver { get; set; }  //determones wether it's game over or not
        public static Direction direction { get; set; }

        public Settings()
        {
            width = 12;
            height = 12;
            speed = 15;
            score = 0;
            points = 100;
            gameOver = false;
            direction = Direction.Down;
        }
    }
}
