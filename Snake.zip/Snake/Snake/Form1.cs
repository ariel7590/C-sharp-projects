﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Snake
{
    public partial class Form1 : Form
    {
        private List<Rect>snake=new List<Rect>();
        private Circle food = new Circle();
        public Form1()
        {
            InitializeComponent();

            //Set settings to default
            new Settings();

            //Set game speed and start timer
            GameTimer.Interval = 1000 / Settings.speed; //this line decides the speed of the game
            GameTimer.Tick += UpdateScreen;
            GameTimer.Start();

            //Start the game
            StartGame();
        }

        private void StartGame()
        {
    
            lbGameOver.Visible = false;
            new Settings();

            //Create the player object
            snake.Clear();
            Rect head = new Rect { x = 10, y = 5 } ;
            snake.Add(head);

            lbScore.Text = Settings.score.ToString();
            GenerateFood();
        }

        //Throws random food
        private void GenerateFood()
        {
            int maxXPose = pbCanvas.Size.Width / Settings.width;
            int maxYPose = pbCanvas.Size.Height / Settings.height;
            Random random = new Random();
            food = new Circle { x = random.Next(0, maxXPose), y = random.Next(0, maxYPose) };
        }
        private void UpdateScreen(object sender, EventArgs e)
        {
            //check for game over
            if(Settings.gameOver)
            {
                //check if enter is pressed
                if (Input.KeyPressed(Keys.Enter))
                {
                    StartGame();
                }
            }
            else
            {
                if (Input.KeyPressed(Keys.Right) && Settings.direction != Direction.Left)
                    Settings.direction = Direction.Right;
               else if (Input.KeyPressed(Keys.Left) && Settings.direction != Direction.Right)
                    Settings.direction = Direction.Left;
               else if (Input.KeyPressed(Keys.Up) && Settings.direction != Direction.Down)
                    Settings.direction = Direction.Up;
               else if (Input.KeyPressed(Keys.Down) && Settings.direction != Direction.Up)
                    Settings.direction = Direction.Down;
                MovePlayer();
            }
            pbCanvas.Invalidate();
        }



        private void pbCanvas_Paint(object sender, PaintEventArgs e)
        {
            Graphics canvas = e.Graphics;

            if(!Settings.gameOver)
            {
                //Set the color of the snake
              //  Brush snakeColor; ==> type this in the for itself

                //Draw snake
                for(int i=0; i<snake.Count; i++)
                {
                    Brush snakeColor;
                    if (i == 0)
                        snakeColor = Brushes.Black;
                    else
                    {
                        if (i % 2 == 0)
                            snakeColor = Brushes.Yellow;
                        else
                            snakeColor = Brushes.Red;
                    }

                    //Draw snake
                    canvas.FillRectangle(snakeColor,
                        new Rectangle(snake[i].x * Settings.width,
                                      snake[i].y * Settings.height,
                                      Settings.width, Settings.height));

                    //Draw food
                   canvas.FillEllipse(Brushes.Red,
                        new Rectangle(food.x * Settings.width,
                        food.y * Settings.height, 10, 10));
                }
            }
            else
            {
                string gameOver = "Game over \nYour final score is: " + Settings.score + "\nPress Enter to try again";
                lbGameOver.Text = gameOver;
                lbGameOver.Visible = true;
            }
        }
        private void MovePlayer()
        {
            
            for(int i=snake.Count-1; i>=0; i--)
            {
                //Move head
                if(i==0)
                {
                    switch(Settings.direction)
                    {
                        case Direction.Right:
                            snake[i].x++;
                            break;
                        case Direction.Left:
                            snake[i].x--;
                            break;
                        case Direction.Up:
                            snake[i].y--;
                            break;
                        case Direction.Down:
                            snake[i].y++;
                            break;
                    }

                    //Get max X and Y pos
                    int maxXPos = pbCanvas.Size.Width / Settings.width;
                    int maxYPos = pbCanvas.Size.Height / Settings.height;

                    //Detect collision with game borders
                    if(snake[i].x<0||snake[i].y<0||snake[i].x>=maxXPos||snake[i].y>=maxYPos)
                    {
                        Die();
                    }
                    
                    //Detect collision with body
                    for(int j=1; j<snake.Count; j++)
                    {
                        if(snake[i].x==snake[j].x&&snake[i].y==snake[j].y)
                        {
                           Die();
                        }
                    }

                    //Detect collision with food piece
                    if(snake[0].x==food.x&&snake[0].y==food.y)
                    {
                        Eat();
                    }
                }
                else
                {
                    //Move body
                    snake[i].x = snake[i - 1].x;
                    snake[i].y = snake[i - 1].y;
                }
            }
        }

        private void Eat()
        {
            //Play sound effect
                SoundPlayer eating = new SoundPlayer(@"C:\Users\ariel\Downloads\ra.wav");
                eating.Load();
                eating.Play();
            //Add rect to body
            Rect rect = new Rect();
            rect.x = snake[snake.Count - 1].x;
            rect.y = snake[snake.Count - 1].y;
            snake.Add(rect);

            //update score
            Settings.score += Settings.points;
            lbScore.Text = Settings.score.ToString();
            GenerateFood();
        }

        private void Die()
        {
            SoundPlayer lose = new SoundPlayer(@"C:\Users\ariel\Downloads\starting_pistol-Stephan_Schutze-613594351.wav");
            lose.Load();
            lose.Play();
            Settings.gameOver = true;
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            Input.ChangeState(e.KeyCode, false);
        }

        private void Form1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            Input.ChangeState(e.KeyCode, true);
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created by Ariel Turchinsky","About");
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StartGame();
        }



        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
