﻿namespace TicTacToe_Forms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.A1 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.A3 = new System.Windows.Forms.Button();
            this.A2 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.C2 = new System.Windows.Forms.Button();
            this.C1 = new System.Windows.Forms.Button();
            this.C3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Xwon = new System.Windows.Forms.Label();
            this.Owon = new System.Windows.Forms.Label();
            this.WhenDraw = new System.Windows.Forms.Label();
            this.resetResultsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectModeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.player1VSPlayer2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.playerVSComputerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(307, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.resetResultsToolStripMenuItem,
            this.selectModeToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.newGameToolStripMenuItem.Text = "New Game";
            this.newGameToolStripMenuItem.Click += new System.EventHandler(this.newGameToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem1});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.aboutToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem1.Text = "About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // A1
            // 
            this.A1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.Location = new System.Drawing.Point(0, 38);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(96, 74);
            this.A1.TabIndex = 1;
            this.A1.UseVisualStyleBackColor = true;
            this.A1.Click += new System.EventHandler(this.Button_Click);
            this.A1.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.A1.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // B2
            // 
            this.B2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(102, 118);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(96, 74);
            this.B2.TabIndex = 2;
            this.B2.UseVisualStyleBackColor = true;
            this.B2.Click += new System.EventHandler(this.Button_Click);
            this.B2.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.B2.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // B1
            // 
            this.B1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(0, 118);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(96, 74);
            this.B1.TabIndex = 3;
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.Button_Click);
            this.B1.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.B1.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // A3
            // 
            this.A3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.Location = new System.Drawing.Point(204, 38);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(96, 74);
            this.A3.TabIndex = 4;
            this.A3.UseVisualStyleBackColor = true;
            this.A3.Click += new System.EventHandler(this.Button_Click);
            this.A3.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.A3.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // A2
            // 
            this.A2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.Location = new System.Drawing.Point(102, 38);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(96, 74);
            this.A2.TabIndex = 5;
            this.A2.UseVisualStyleBackColor = true;
            this.A2.Click += new System.EventHandler(this.Button_Click);
            this.A2.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.A2.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // B3
            // 
            this.B3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(204, 118);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(96, 74);
            this.B3.TabIndex = 6;
            this.B3.UseVisualStyleBackColor = true;
            this.B3.Click += new System.EventHandler(this.Button_Click);
            this.B3.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.B3.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // C2
            // 
            this.C2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.Location = new System.Drawing.Point(102, 198);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(96, 74);
            this.C2.TabIndex = 7;
            this.C2.UseVisualStyleBackColor = true;
            this.C2.Click += new System.EventHandler(this.Button_Click);
            this.C2.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.C2.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // C1
            // 
            this.C1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.Location = new System.Drawing.Point(0, 198);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(96, 74);
            this.C1.TabIndex = 8;
            this.C1.UseVisualStyleBackColor = true;
            this.C1.Click += new System.EventHandler(this.Button_Click);
            this.C1.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.C1.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // C3
            // 
            this.C3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.Location = new System.Drawing.Point(204, 198);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(96, 74);
            this.C3.TabIndex = 9;
            this.C3.UseVisualStyleBackColor = true;
            this.C3.Click += new System.EventHandler(this.Button_Click);
            this.C3.MouseEnter += new System.EventHandler(this.WhichTurn);
            this.C3.MouseLeave += new System.EventHandler(this.EndPreview);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(0, 291);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "X Won";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(109, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 24);
            this.label2.TabIndex = 11;
            this.label2.Text = "O Won";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(221, 291);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 24);
            this.label3.TabIndex = 12;
            this.label3.Text = "Draw";
            // 
            // Xwon
            // 
            this.Xwon.AutoSize = true;
            this.Xwon.Location = new System.Drawing.Point(25, 326);
            this.Xwon.Name = "Xwon";
            this.Xwon.Size = new System.Drawing.Size(13, 13);
            this.Xwon.TabIndex = 13;
            this.Xwon.Text = "0";
            // 
            // Owon
            // 
            this.Owon.AutoSize = true;
            this.Owon.Location = new System.Drawing.Point(136, 326);
            this.Owon.Name = "Owon";
            this.Owon.Size = new System.Drawing.Size(13, 13);
            this.Owon.TabIndex = 14;
            this.Owon.Text = "0";
            // 
            // WhenDraw
            // 
            this.WhenDraw.AutoSize = true;
            this.WhenDraw.Location = new System.Drawing.Point(240, 326);
            this.WhenDraw.Name = "WhenDraw";
            this.WhenDraw.Size = new System.Drawing.Size(13, 13);
            this.WhenDraw.TabIndex = 15;
            this.WhenDraw.Text = "0";
            // 
            // resetResultsToolStripMenuItem
            // 
            this.resetResultsToolStripMenuItem.Name = "resetResultsToolStripMenuItem";
            this.resetResultsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.resetResultsToolStripMenuItem.Text = "Reset Results";
            this.resetResultsToolStripMenuItem.Click += new System.EventHandler(this.resetResultsToolStripMenuItem_Click);
            // 
            // selectModeToolStripMenuItem
            // 
            this.selectModeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.player1VSPlayer2ToolStripMenuItem,
            this.playerVSComputerToolStripMenuItem});
            this.selectModeToolStripMenuItem.Name = "selectModeToolStripMenuItem";
            this.selectModeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.selectModeToolStripMenuItem.Text = "Select Mode";
            // 
            // player1VSPlayer2ToolStripMenuItem
            // 
            this.player1VSPlayer2ToolStripMenuItem.Name = "player1VSPlayer2ToolStripMenuItem";
            this.player1VSPlayer2ToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.player1VSPlayer2ToolStripMenuItem.Text = "Player 1 VS Player 2";
            this.player1VSPlayer2ToolStripMenuItem.Click += new System.EventHandler(this.player1VSPlayer2ToolStripMenuItem_Click);
            // 
            // playerVSComputerToolStripMenuItem
            // 
            this.playerVSComputerToolStripMenuItem.Name = "playerVSComputerToolStripMenuItem";
            this.playerVSComputerToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.playerVSComputerToolStripMenuItem.Text = "Player VS Computer";
            this.playerVSComputerToolStripMenuItem.Click += new System.EventHandler(this.playerVSComputerToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Menu;
            this.ClientSize = new System.Drawing.Size(307, 365);
            this.Controls.Add(this.WhenDraw);
            this.Controls.Add(this.Owon);
            this.Controls.Add(this.Xwon);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Tic Tac Toe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button C2;
        private System.Windows.Forms.Button C1;
        private System.Windows.Forms.Button C3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Xwon;
        private System.Windows.Forms.Label Owon;
        private System.Windows.Forms.Label WhenDraw;
        private System.Windows.Forms.ToolStripMenuItem resetResultsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectModeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem player1VSPlayer2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem playerVSComputerToolStripMenuItem;
    }
}

