﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe_Forms
{
    public partial class Form1 : Form
    {
        bool turn=true; //when true=>X , when false=>O
        int turnCount = 0;
        bool winner=false;
        bool against_computer = false;

#region Constructor
        public Form1()
        {
            InitializeComponent();
        }
        #endregion

#region Button_Click
        private void Button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (turn == true)
            {
                b.ForeColor = Color.Blue;
                b.Text = "X";
                b.Enabled = false;
                turnCount++;
                if(turnCount<9)
                turn = !turn;
                WinCheck();
                Draw();
            }
           else
            {
                b.ForeColor = Color.Red;
                b.Text = "O";
                b.Enabled = false;
                turnCount++;
                if(turnCount<9)
                turn = !turn;
                WinCheck();
                Draw();
            }
            if((!turn)&&(against_computer))
            {
                System.Threading.Thread.Sleep(500);
                ComputerMakeMove();
            }

        }
        private void ComputerMakeMove()
        {
            Button move = null;

            //Look for tic tac toe opportunities
            move = LookForWinOrBlock("O"); //Look for win
            if(move==null)
            {
                move = LookForWinOrBlock("X");//Look for block
                if(move==null)
                {
                    move = LookForCorner();
                    if(move==null)
                    {
                        move = LookForOpenSpace();
                    }
                }
            }
            try
            {
                move.PerformClick();
            }
            catch { };
        }
        private Button LookForOpenSpace()
        {
            Console.WriteLine("Looking for open space");
            Button b = null;
            foreach (Control c in Controls)
            {
                b = c as Button;
                if(b !=null)
                {
                    if ((b.Text == "")&&(!winner))
                        return b;
                }
            }
            return null;
        }
        private Button LookForCorner()
        {
            Console.WriteLine("Looking for corner");
            if ((A1.Text == "O") && (!winner))
            {
                if (A3.Text == "")
                    return A3;
                if (C3.Text == "")
                    return C3;
                if (C1.Text == "")
                    return C1;
            }

            if ((A3.Text == "O") && (!winner))
            {
                if (A1.Text == "")
                    return A1;
                if (C3.Text == "")
                    return C3;
                if (C1.Text == "")
                    return C1;
            }

            if ((C3.Text == "O") && (!winner))
            {
                if (A1.Text == "")
                    return A3;
                if (A3.Text == "")
                    return A3;
                if (C1.Text == "")
                    return C1;
            }

            if ((C1.Text == "O") && (!winner))
            {
                if (A1.Text == "")
                    return A3;
                if (A3.Text == "")
                    return A3;
                if (C3.Text == "")
                    return C3;
            }

            if ((A1.Text == "") && (!winner))
                return A1;
            if ((A3.Text == "") && (!winner))
                return A3;
            if ((C1.Text == "") && (!winner))
                return C1;
            if ((C3.Text == "") && (!winner))
                return C3;

            return null;
        }
        private Button LookForWinOrBlock(string mark)
        {
            Console.WriteLine("Looking for win or block:  " + mark);
            //HORIZONTAL TESTS
            if ((A1.Text == mark) && (A2.Text == mark) && (A3.Text == "")&&(!winner))
                return A3;
            if ((A2.Text == mark) && (A3.Text == mark) && (A1.Text == "") && (!winner))
                return A1;
            if ((A1.Text == mark) && (A3.Text == mark) && (A2.Text == "") && (!winner))
                return A2;

            if ((B1.Text == mark) && (B2.Text == mark) && (B3.Text == "") && (!winner))
                return B3;
            if ((B2.Text == mark) && (B3.Text == mark) && (B1.Text == "") && (!winner))
                return B1;
            if ((B1.Text == mark) && (B3.Text == mark) && (B2.Text == "") && (!winner))
                return B2;

            if ((C1.Text == mark) && (C2.Text == mark) && (C3.Text == "") && (!winner))
                return C3;
            if ((C2.Text == mark) && (C3.Text == mark) && (C1.Text == "") && (!winner))
                return C1;
            if ((C1.Text == mark) && (C3.Text == mark) && (C2.Text == "") && (!winner))
                return C2;

            //VERTICAL TESTS
            if ((A1.Text == mark) && (B1.Text == mark) && (C1.Text == "") && (!winner))
                return C1;
            if ((B1.Text == mark) && (C1.Text == mark) && (A1.Text == "") && (!winner))
                return A1;
            if ((A1.Text == mark) && (C1.Text == mark) && (B1.Text == "") && (!winner))
                return B1;

            if ((A2.Text == mark) && (B2.Text == mark) && (C2.Text == "") && (!winner))
                return C2;
            if ((B2.Text == mark) && (C2.Text == mark) && (A2.Text == "") && (!winner))
                return A2;
            if ((A2.Text == mark) && (C2.Text == mark) && (B2.Text == "") && (!winner))
                return B2;

            if ((A3.Text == mark) && (B3.Text == mark) && (C3.Text == "") && (!winner))
                return C3;
            if ((B3.Text == mark) && (C3.Text == mark) && (A3.Text == "") && (!winner))
                return A3;
            if ((A3.Text == mark) && (C3.Text == mark) && (B3.Text == "") && (!winner))
                return B3;

            //DIAGONAL TESTS
            if ((A1.Text == mark) && (B2.Text == mark) && (C3.Text == "") && (!winner))
                return C3;
            if ((B2.Text == mark) && (C3.Text == mark) && (A1.Text == "") && (!winner))
                return A1;
            if ((A1.Text == mark) && (C3.Text == mark) && (B2.Text == "") && (!winner))
                return B2;

            if ((A3.Text == mark) && (B2.Text == mark) && (C1.Text == "") && (!winner))
                return C1;
            if ((B2.Text == mark) && (C1.Text == mark) && (A3.Text == "") && (!winner))
                return A3;
            if ((A3.Text == mark) && (C1.Text == mark) && (B2.Text == "") && (!winner))
                return B2;

            return null;
        }
        #endregion

        private void WinCheck()
        {
         
            //Horizontal
            if(A1.Text==A2.Text&&A2.Text==A3.Text&&!A1.Enabled)
            {
                winner = true;
                WinChecker();
                


            }
            if (B1.Text == B2.Text && B2.Text == B3.Text && !B1.Enabled)
            {
                winner = true;
                WinChecker();



            }
            if (C1.Text == C2.Text && C2.Text == C3.Text && !C1.Enabled)
            {
                winner = true;
                WinChecker();



            }

            //Vertical
            if (A1.Text == B1.Text && B1.Text == C1.Text && !C1.Enabled)
            {
                winner = true;
                WinChecker();



            }
            if (A2.Text == B2.Text && B2.Text == C2.Text && !A2.Enabled)
            {
                winner = true;
                WinChecker();



            }
            if (A3.Text == B3.Text && B3.Text == C3.Text && !C3.Enabled)
            {
                winner = true;
                WinChecker();



            }

            //Diagonal
            if (A1.Text == B2.Text && B2.Text == C3.Text && !A1.Enabled)
            {
                winner = true;
                WinChecker();



            }
            if (A3.Text == B2.Text && B2.Text == C1.Text && !C1.Enabled)
            {
                winner = true;
                WinChecker();



            }
            void WinChecker()
            {
                if (winner)
                {
                    if (!turn)
                    {
                        
                        MessageBox.Show("X Wins!", "Winner");
                        Xwon.Text = (Int32.Parse(Xwon.Text) + 1).ToString(); //Label when X wins
                        
                        return;

                    }
                    else
                    {
                        MessageBox.Show("O Wins!", "Winner");
                        Owon.Text = (Int32.Parse(Owon.Text) + 1).ToString(); //Label when O wins

                    }
                    ButtonsDisabled();
                    winner = !winner;
                }
            }
         
            if((winner)&&(against_computer)&&(turn))
            {
                SoundPlayer player = new SoundPlayer(@"C:\Users\ariel\Downloads\fart-04.wav");
                player.Load();
                player.Play();
            }
            if ((winner) && (against_computer) && (!turn))
            {
                SoundPlayer player1 = new SoundPlayer(@"C:\Users\ariel\Downloads\Ta Da-SoundBible.com-1884170640.wav");
                player1.Load();
                player1.Play();
            }


        }


        private void ButtonsDisabled()
        {
           // try
           // {
                foreach (Control c in Controls)
                {
                try
                {
                    Button b = (Button)c;
                    b.Enabled = false;
                }
                catch { }
                
                
                 }
           // }
          //  catch { }


        }

        
        private void Draw()
        {
         
                if (turnCount == 9&&winner==false)
                {
                    MessageBox.Show("It's a Draw!", "Draw");
                WhenDraw.Text = (Int32.Parse(WhenDraw.Text) + 1).ToString();

                }
           
        }
        

        private void Reset()
        {
            turn = true;
            turnCount = 0;
            winner = false;
            
                foreach (Control c in Controls)
                {
                try
                {
                    Button b = (Button)c;
                    b.Enabled = true;
                    b.Text = "";
                }
                catch { }
            }
           
        }

 
        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created by Ariel Turchinsky ©", "About");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Reset();
        }
        


        private void WhichTurn(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (b.Enabled)
            {
                if (turn)
                {
                    b.ForeColor = Color.Blue;
                    b.Text = "X";
                }
                else
                {
                    b.ForeColor = Color.Red;
                    b.Text = "O";
                }
            }
        }

        private void EndPreview(object sender, EventArgs e)
        {
           
            Button b = (Button)sender;
            if(b.Enabled)
            b.Text = "";
        }
        

        private void resetResultsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Xwon.Text = "0";
            Owon.Text = "0";
            WhenDraw.Text = "0";
        }

        private void playerVSComputerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            against_computer = true;
        }

        private void player1VSPlayer2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            against_computer = false;
        }
    }
}
