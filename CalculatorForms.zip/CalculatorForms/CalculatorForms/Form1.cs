﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorForms
{
    public partial class Form1 : Form
    {
       double num1=0, num2=0, result=0;
        bool op = false;
        char operation;
        bool pos1=true; //האם המספר חיובי או שלילי, טרו זה חיובי
        bool pos2 = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void Bclick(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (textBox.Text == result.ToString())  //מנקה את המסך אחרי שקיבלתי תוצאה ואני נותן מספר חדש
            {
                textBox.Clear();
                pos1 = true;                //מחזיר אותם להיות חיוביים לפי ברירת מחדל
                pos2 = true;
            }
            if(b.Text==".")
            {
                if (!op)
                {
                    if (!textBox.Text.Contains("."))
                         textBox.Text += b.Text;
                }
                else
                {
                    Split();
                    if (!num2.ToString().Contains("."))
                    {
                        textBox.Text += b.Text;

                    }
                }
            }
            else
            textBox.Text += b.Text;
        }

        private void Operation(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            op = true;
            operation = char.Parse(b.Text);
            textBox.Text += b.Text;
            if(textBox.Text==result.ToString())
            {
                if (result >= 0)
                    pos1 = true;
                else if(result<0)
                    pos1 = false;
            }
        }

        private void PosNeg(object sender, EventArgs e)
        {
            if (!op) //אם לא בוצעה פעולת חשבון
            {
                textBox.Text = (0 - double.Parse(textBox.Text)).ToString();
                pos1 = !pos1;
            }
            else
            {
                Split();
                if (pos2)
                {
                    num2 = 0 - num2;
                    textBox.Text = num1.ToString() + operation + "(" + num2;
                    pos2 = !pos2;
                }
                else
                {
                    num2 = 0 - num2;
                    textBox.Text = num1.ToString() + operation + num2;
                    pos2 = !pos2;

                }
            }
            //else
            //{
            //    if (!op)
            //        textBox.Text = (0 - double.Parse(textBox.Text)).ToString();
            //    else
            //    {
            //        Split();
            //        textBox.Text = num1.ToString() + (0 - num2).ToString();
            //    }
            //     pos = !pos;
            //}
        }

        private void Result(object sender, EventArgs e)
        {
            if(op)
            {
                Split();
                switch (operation)
                {
                    case '+':
                        result = num1 + num2;
                        textBox.Text = result.ToString();
                        break;
                    case '-':
                        result = num1 - num2;
                        textBox.Text = result.ToString();
                        break;
                    case 'x':
                        result = num1 * num2;
                        textBox.Text = result.ToString();
                        break;
                    case '÷':
                        result = num1 / num2;
                        textBox.Text = result.ToString();
                        break;
                    default:
                        break;
                }    
            }
            op = false;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.NumPad1:
                    b1.PerformClick();
                    b1.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad2:
                    b2.PerformClick();
                    b2.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad3:
                    b3.PerformClick();
                    b3.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad4:
                    b4.PerformClick();
                    b4.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad5:
                    b5.PerformClick();
                    b5.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad6:
                    b6.PerformClick();
                    b6.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad7:
                    b7.PerformClick();
                    b7.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad8:
                    b8.PerformClick();
                    b8.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad9:
                    b9.PerformClick();
                    b9.BackColor = Color.LightBlue;
                    break;
                case Keys.NumPad0:
                    b0.PerformClick();
                    b0.BackColor = Color.LightBlue;
                    break;
                case Keys.Add:
                    bAdd.PerformClick();
                    bAdd.BackColor = Color.LightBlue;
                    break;
                case Keys.Subtract:
                    bSub.PerformClick();
                    bSub.BackColor = Color.LightBlue;
                    break;
                case Keys.Multiply:
                    bMul.PerformClick();
                    bMul.BackColor = Color.LightBlue;
                    break;
                case Keys.Divide:
                    bDiv.PerformClick();
                    bDiv.BackColor = Color.LightBlue;
                    break;
                case Keys.Decimal:
                    bPoint.PerformClick();
                    bPoint.BackColor = Color.LightBlue;
                    break;
                case Keys.Enter:
                    bEquals.PerformClick();
                    bEquals.BackColor = Color.LightBlue;
                    break;
                case Keys.C:
                    bClear.PerformClick();
                    bClear.BackColor = Color.LightBlue;
                    break;
                case Keys.V:
                    bPosNeg.PerformClick();
                    bPosNeg.BackColor = Color.LightBlue;
                    break;
                default:
                    break;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.NumPad1:
                    b1.BackColor = default(Color);
                    b1.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad2:
                    b2.BackColor = default(Color);
                    b2.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad3:
                    b3.BackColor = default(Color);
                    b3.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad4:
                    b4.BackColor = default(Color);
                    b4.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad5:
                    b5.BackColor = default(Color);
                    b5.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad6:
                    b6.BackColor = default(Color);
                    b6.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad7:
                    b7.BackColor = default(Color);
                    b7.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad8:
                    b8.BackColor = default(Color);
                    b8.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad9:
                    b9.BackColor = default(Color);
                    b9.UseVisualStyleBackColor = true;
                    break;
                case Keys.NumPad0:
                    b0.BackColor = default(Color);
                    b0.UseVisualStyleBackColor = true;
                    break;
                case Keys.Add:
                    bAdd.BackColor = default(Color);
                    bAdd.UseVisualStyleBackColor = true;
                    break;
                case Keys.Subtract:
                    bSub.BackColor = default(Color);
                    bSub.UseVisualStyleBackColor = true;
                    break;
                case Keys.Multiply:
                    bMul.BackColor = default(Color);
                    bMul.UseVisualStyleBackColor = true;
                    break;
                case Keys.Divide:
                    bDiv.BackColor = default(Color);
                    bDiv.UseVisualStyleBackColor = true;
                    break;
                case Keys.Decimal:
                    bPoint.BackColor = default(Color);
                    bPoint.UseVisualStyleBackColor = true;
                    break;
                case Keys.Enter:
                    bEquals.BackColor = default(Color);
                    bEquals.UseVisualStyleBackColor = true;
                    break;
                case Keys.C:
                    bClear.BackColor = default(Color);
                    bClear.UseVisualStyleBackColor = true;
                    break;
                case Keys.V:
                    bPosNeg.BackColor = default(Color);
                    bPosNeg.UseVisualStyleBackColor = true;
                    break;
                default:
                    break;
            }
        }

        private void Clear(object sender, EventArgs e)
        {
            textBox.Clear();
            num1 = 0;
            num2 = 0;
            result = 0;
            op = false;
            pos1 = true;
            pos2 = true;
        }

        private void Split()  //מפצל את שני המספרים שבפעולת החשבון לשני משתנים נפרדים
        {
            try
            {
                string[] substrings = textBox.Text.Split(operation);
                num1 = double.Parse(substrings[0]);
                num2 = double.Parse(substrings[1]);
            }
            catch
            {
                
            };
        }


    }
}
